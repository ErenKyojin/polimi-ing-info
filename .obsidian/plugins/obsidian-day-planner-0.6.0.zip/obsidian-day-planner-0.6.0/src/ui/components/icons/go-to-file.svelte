<svg
  class="svg-icon lucide lucide-file-input"
  fill="none"
  height="24"
  stroke="currentColor"
  stroke-linecap="round"
  stroke-linejoin="round"
  stroke-width="2"
  viewBox="0 0 24 24"
  width="24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path d="M4 22h14a2 2 0 0 0 2-2V7.5L14.5 2H6a2 2 0 0 0-2 2v4" />
  <polyline points="14 2 14 8 20 8" />
  <path d="M2 15h10" />
  <path d="m9 18 3-3-3-3" />
</svg>
